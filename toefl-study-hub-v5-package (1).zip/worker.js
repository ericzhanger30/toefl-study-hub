export default {
  async fetch(request) {
    const cors = {
      "Access-Control-Allow-Origin": "https://ericzhanger30.github.io",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Vary": "Origin"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return Response.json({ error: "请使用 POST 请求" }, { status: 405, headers: cors });
    const origin = request.headers.get("Origin") || "";
    if (origin && origin !== "https://ericzhanger30.github.io") {
      return Response.json({ error: "不允许的来源网站" }, { status: 403, headers: cors });
    }
    try {
      const body = await request.json();
      const word = String(body.word || "").trim();
      if (!word || word.length > 80 || !/^[A-Za-z][A-Za-z' -]*$/.test(word)) {
        return Response.json({ error: "请输入有效的英文单词" }, { status: 400, headers: cors });
      }
      let definition = "";
      try {
        const dr = await fetch("https://api.dictionaryapi.dev/api/v2/entries/en/" + encodeURIComponent(word));
        if (dr.ok) {
          const dj = await dr.json();
          definition = (dj[0]?.meanings || []).flatMap(m => (m.definitions || []).slice(0, 2).map(d => d.definition)).slice(0, 3).join("; ");
        }
      } catch (_) {}
      const source = definition || word;
      const tr = await fetch("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=zh-CN&dt=t&q=" + encodeURIComponent(source), { headers: { "User-Agent": "Mozilla/5.0" } });
      if (!tr.ok) throw new Error("翻译服务暂时不可用，请稍后重试");
      const tj = await tr.json();
      const meaning = (tj?.[0] || []).map(part => part?.[0] || "").join("").trim();
      if (!meaning) throw new Error("没有获取到中文释义");
      return Response.json({ word, meaning, definition }, { headers: cors });
    } catch (e) {
      return Response.json({ error: e.message || "翻译失败" }, { status: 502, headers: cors });
    }
  }
};
