# TOEFL Study Hub V5：自动中文释义 + 手动修改

## 你会得到什么
- `index.html`：要上传到现有 GitHub Pages 仓库根目录的网站文件。
- `worker.js`：Cloudflare Worker 翻译桥接代码。

## 第一步：部署免费的 Cloudflare Worker（只需做一次）
1. 登录/注册 Cloudflare：https://dash.cloudflare.com/ （免费计划即可）。
2. 在左侧打开 **Workers & Pages**。
3. 选择 **Create** / **Create application**，再选择 **Create Worker**。
4. 给 Worker 起名，例如 `toefl-vocab-translate`，然后部署。
5. 部署后打开 Worker 的 **Edit code**。
6. 删除编辑器里的示例代码，把本包的 `worker.js` 全部复制进去。
7. 点击 **Deploy** 保存。
8. 复制 Worker 提供的网址，格式类似 `https://toefl-vocab-translate.你的账号.workers.dev`。

## 第二步：更新 GitHub Pages 网站
1. 打开 https://github.com/ericzhanger30/toefl-study-hub
2. 将本包里的 `index.html` 上传到仓库根目录，替换原有 `index.html`。
3. 点击 **Commit changes**，等待 GitHub Pages 部署成功。

## 第三步：连接翻译服务
1. 打开 https://ericzhanger30.github.io/toefl-study-hub/
2. 进入 Vocabulary bank。
3. 在“免费翻译服务地址”输入框粘贴刚才的 `workers.dev` 地址。
4. 粘贴单词并点击“添加单词并生成中文释义”。
5. 每个词都有“重新翻译”和“编辑”按钮。

## 重要说明
- Cloudflare Workers 免费计划有使用额度和条款限制；请查看 Cloudflare 当前免费计划说明。
- Worker 使用免费的公开词典 API 获取英文释义，并调用 Google Translate 的非官方公开接口翻译。它不需要 API 密钥，但第三方服务可能限流、变更或暂时不可用。
- 自动释义可能不符合某个 TOEFL 题目语境，请人工检查。
- 词汇和错题仍保存在当前浏览器的 localStorage；请定期导出备份。它们不会自动跨设备同步。
- 原有存储键 `toefl-study-hub-v1` 保持不变，正常更新不会清空当前浏览器里的记录。
